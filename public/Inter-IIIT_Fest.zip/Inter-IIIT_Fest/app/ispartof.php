<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ispartof extends Model
{
	protected $table = "ispartof";
}
