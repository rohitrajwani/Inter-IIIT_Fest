<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registersfor extends Model
{
	protected $table = "registerfor";
}
